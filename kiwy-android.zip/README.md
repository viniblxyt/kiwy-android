# Kiwy para Android

App nativo do Kiwy (https://kiwy-ai.vercel.app) com acesso ao celular:
abrir apps, achar contatos pelo nome, mandar WhatsApp e SMS, ligar, criar alarme e timer,
lanterna, volume, configurações e reconhecimento de voz.

## Baixar
Vá em **Releases** e baixe o `kiwy.apk` da versão mais recente.

Cada envio para `main` gera um APK novo automaticamente (GitHub Actions).
