package app.kiwy.android;

import android.accessibilityservice.AccessibilityService;
import android.content.ComponentName;
import android.content.Context;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.List;

/**
 * Opcional: quando o usuário ativa em Acessibilidade, toca em "Enviar" no WhatsApp
 * apenas nos 15 segundos seguintes a um pedido feito ao Kiwy. Não lê nem guarda conversas.
 */
public class AutoSendService extends AccessibilityService {
    static volatile long armedUntil = 0;

    static void arm() { armedUntil = System.currentTimeMillis() + 15000; }

    static void disarm() { armedUntil = 0; }

    static boolean isEnabled(Context c) {
        String list = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (TextUtils.isEmpty(list)) return false;
        String me = new ComponentName(c, AutoSendService.class).flattenToString();
        for (String s : list.split(":")) if (s.equalsIgnoreCase(me)) return true;
        return false;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (System.currentTimeMillis() > armedUntil) return;
        CharSequence pkg = e.getPackageName();
        if (pkg == null || !pkg.toString().startsWith("com.whatsapp")) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        try {
            AccessibilityNodeInfo send = find(root, pkg + ":id/send");
            if (send == null) send = findByDesc(root, new String[]{"Enviar", "Send"});
            if (send != null && send.isEnabled()) {
                AccessibilityNodeInfo n = send;
                while (n != null && !n.isClickable()) n = n.getParent();
                if (n != null && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) disarm();
            }
        } catch (Exception ignored) {}
    }

    static AccessibilityNodeInfo find(AccessibilityNodeInfo root, String viewId) {
        List<AccessibilityNodeInfo> l = root.findAccessibilityNodeInfosByViewId(viewId);
        return l == null || l.isEmpty() ? null : l.get(0);
    }

    static AccessibilityNodeInfo findByDesc(AccessibilityNodeInfo node, String[] names) {
        if (node == null) return null;
        CharSequence d = node.getContentDescription();
        if (d != null) for (String n : names) if (n.equalsIgnoreCase(d.toString())) return node;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo r = findByDesc(node.getChild(i), names);
            if (r != null) return r;
        }
        return null;
    }

    @Override
    public void onInterrupt() {}
}
