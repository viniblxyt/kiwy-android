package app.kiwy.android;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.provider.AlarmClock;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.telephony.SmsManager;

import org.json.JSONObject;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;

/** Executa as ações pedidas pelo Kiwy (mesmo formato JSON dos blocos <kiwy-act>). */
class Actions {
    final MainActivity act;

    Actions(MainActivity a) { act = a; }

    static String norm(String s) {
        if (s == null) return "";
        String n = Normalizer.normalize(s.toLowerCase().trim(), Normalizer.Form.NFD);
        return n.replaceAll("\\p{M}", "").replaceAll("^(o|a|os|as) ", "");
    }

    void done(String id, boolean ok, String msg) { done(id, ok, msg, null); }

    void done(String id, boolean ok, String msg, JSONObject extra) {
        JSONObject r = extra != null ? extra : new JSONObject();
        try { r.put("ok", ok); r.put("message", msg); } catch (Exception ignored) {}
        act.reply(id, r);
    }

    boolean start(Intent i) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            act.startActivity(i);
            return true;
        } catch (ActivityNotFoundException | SecurityException e) {
            return false;
        }
    }

    void run(String id, String json) {
        JSONObject a;
        try { a = new JSONObject(json); } catch (Exception e) { done(id, false, "Ação inválida."); return; }
        String tipo = norm(a.optString("tipo"));
        try {
            switch (tipo) {
                case "abrir": openApp(id, a.optString("app")); break;
                case "galeria": openApp(id, "galeria"); break;
                case "whatsapp": withContact(id, a, (name, phone) -> whatsapp(id, name, phone, a.optString("texto"))); break;
                case "sms": withContact(id, a, (name, phone) -> sms(id, name, phone, a.optString("texto"))); break;
                case "ligar": withContact(id, a, (name, phone) -> call(id, name, phone)); break;
                case "contato": withContact(id, a, (name, phone) -> done(id, true, name + ": " + phone, MainActivity.obj("name", name, "phone", phone))); break;
                case "alarme": alarm(id, a); break;
                case "timer": case "temporizador": timer(id, a); break;
                case "lanterna": torch(id, a.optBoolean("ligar", true)); break;
                case "volume": volume(id, a); break;
                case "config": case "configuracoes": settings(id, a.optString("painel")); break;
                case "email": {
                    Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + Uri.encode(a.optString("para"))));
                    i.putExtra(Intent.EXTRA_SUBJECT, a.optString("assunto"));
                    i.putExtra(Intent.EXTRA_TEXT, a.optString("texto"));
                    done(id, start(i), "E-mail aberto.");
                    break;
                }
                case "mapa": {
                    String q = Uri.encode(a.optString("consulta"));
                    Uri u = a.optBoolean("rota") ? Uri.parse("google.navigation:q=" + q) : Uri.parse("geo:0,0?q=" + q);
                    boolean ok = start(new Intent(Intent.ACTION_VIEW, u));
                    if (!ok) ok = start(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=" + q)));
                    done(id, ok, ok ? "Mapa aberto." : "Não encontrei um app de mapas.");
                    break;
                }
                case "pesquisar": {
                    Intent i = new Intent(Intent.ACTION_WEB_SEARCH);
                    i.putExtra("query", a.optString("consulta"));
                    boolean ok = start(i) || start(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(a.optString("consulta")))));
                    done(id, ok, "Pesquisa aberta.");
                    break;
                }
                case "link": done(id, start(new Intent(Intent.ACTION_VIEW, Uri.parse(a.optString("url")))), "Link aberto."); break;
                default: done(id, false, "Esse tipo de ação ainda não existe no app.");
            }
        } catch (Exception e) {
            done(id, false, "Não consegui fazer isso: " + e.getMessage());
        }
    }

    // ---------- Apps ----------
    void openApp(String id, String name) {
        String n = norm(name);
        PackageManager pm = act.getPackageManager();
        Intent special = null;
        if (n.matches("galeria|fotos?|imagens")) {
            special = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY);
        } else if (n.matches("camera|cam")) {
            special = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
        } else if (n.matches("telefone|discador")) {
            special = new Intent(Intent.ACTION_DIAL);
        } else if (n.matches("mensagens|sms")) {
            special = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING);
        } else if (n.matches("contatos")) {
            special = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CONTACTS);
        } else if (n.matches("calculadora")) {
            special = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALCULATOR);
        } else if (n.matches("agenda|calendario")) {
            special = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR);
        } else if (n.matches("relogio|despertador|alarmes?")) {
            special = new Intent(AlarmClock.ACTION_SHOW_ALARMS);
        } else if (n.matches("configuracoes|ajustes|config")) {
            special = new Intent(Settings.ACTION_SETTINGS);
        } else if (n.matches("navegador|internet|chrome")) {
            special = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER);
        } else if (n.matches("musica|musicas")) {
            special = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC);
        } else if (n.matches("e-?mail|email")) {
            special = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_EMAIL);
        }
        if (special != null && start(special)) { done(id, true, "Abri " + name + "."); return; }

        // Procura entre os apps instalados pelo nome
        Intent main = new Intent(Intent.ACTION_MAIN);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps = pm.queryIntentActivities(main, 0);
        ResolveInfo best = null;
        int bestScore = 0;
        for (ResolveInfo r : apps) {
            String label = norm(String.valueOf(r.loadLabel(pm)));
            String pkg = r.activityInfo.packageName.toLowerCase();
            int score = 0;
            if (label.equals(n)) score = 100;
            else if (label.startsWith(n)) score = 80;
            else if (label.contains(n)) score = 60;
            else if (n.contains(label) && label.length() > 2) score = 50;
            else if (pkg.contains(n.replace(" ", ""))) score = 40;
            if (score > bestScore) { bestScore = score; best = r; }
        }
        if (best != null) {
            Intent i = pm.getLaunchIntentForPackage(best.activityInfo.packageName);
            if (i != null && start(i)) { done(id, true, "Abri " + best.loadLabel(pm) + "."); return; }
        }
        done(id, false, "Não encontrei o app \"" + name + "\" neste celular.");
    }

    // ---------- Contatos ----------
    interface ContactCb { void got(String name, String phone); }

    void withContact(String id, JSONObject a, ContactCb cb) {
        String phone = a.optString("telefone").trim();
        String name = a.optString("contato").trim();
        if (!phone.isEmpty()) { cb.got(name.isEmpty() ? phone : name, phone); return; }
        if (name.isEmpty()) { done(id, false, "Para quem? Diga o nome do contato."); return; }
        act.withPermissions(new String[]{Manifest.permission.READ_CONTACTS}, () -> {
            List<String[]> found = findContacts(name);
            if (found.isEmpty()) { done(id, false, "Não achei \"" + name + "\" nos seus contatos."); return; }
            String[] c = found.get(0);
            cb.got(c[0], c[1]);
        }, () -> done(id, false, "Preciso da permissão de contatos para achar \"" + name + "\"."));
    }

    /** Retorna [nome, telefone] ordenados por quão bem o nome bate. */
    List<String[]> findContacts(String query) {
        String q = norm(query);
        List<String[]> exact = new ArrayList<>(), starts = new ArrayList<>(), has = new ArrayList<>();
        String[] proj = {ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.IS_SUPER_PRIMARY};
        try (Cursor c = act.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, proj, null, null,
                ContactsContract.CommonDataKinds.Phone.TIMES_CONTACTED + " DESC")) {
            if (c == null) return has;
            List<String> seen = new ArrayList<>();
            while (c.moveToNext()) {
                String n = c.getString(0), p = c.getString(1);
                if (n == null || p == null) continue;
                String nn = norm(n);
                if (seen.contains(nn)) continue;
                String[] item = {n, p};
                if (nn.equals(q)) exact.add(item);
                else if (nn.startsWith(q + " ") || nn.startsWith(q)) starts.add(item);
                else if (nn.contains(" " + q) || nn.contains(q)) has.add(item);
                else continue;
                seen.add(nn);
            }
        } catch (Exception ignored) {}
        exact.addAll(starts);
        exact.addAll(has);
        return exact;
    }

    static String digits(String phone) {
        String d = phone.replaceAll("[^\\d+]", "");
        if (d.startsWith("+")) return d.substring(1);
        d = d.replaceAll("^0+", "");
        if (d.length() == 10 || d.length() == 11) d = "55" + d;
        return d;
    }

    // ---------- Mensagens e ligações ----------
    void whatsapp(String id, String name, String phone, String text) {
        Uri u = Uri.parse("https://api.whatsapp.com/send?phone=" + digits(phone) + (text.isEmpty() ? "" : "&text=" + Uri.encode(text)));
        boolean auto = !text.isEmpty() && AutoSendService.isEnabled(act);
        if (auto) AutoSendService.arm();
        for (String pkg : new String[]{"com.whatsapp", "com.whatsapp.w4b"}) {
            Intent i = new Intent(Intent.ACTION_VIEW, u).setPackage(pkg);
            if (start(i)) {
                done(id, true, auto ? "Mensagem enviada para " + name + " no WhatsApp." : "Abri a conversa com " + name + " no WhatsApp; é só tocar em enviar.", MainActivity.obj("name", name, "phone", phone, "auto", auto));
                return;
            }
        }
        AutoSendService.disarm();
        done(id, false, "O WhatsApp não está instalado.");
    }

    void sms(String id, String name, String phone, String text) {
        if (text.isEmpty()) {
            done(id, start(new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + phone))), "Abri as mensagens para " + name + ".");
            return;
        }
        act.withPermissions(new String[]{Manifest.permission.SEND_SMS}, () -> {
            try {
                SmsManager sm = Build.VERSION.SDK_INT >= 31 ? act.getSystemService(SmsManager.class) : SmsManager.getDefault();
                ArrayList<String> parts = sm.divideMessage(text);
                sm.sendMultipartTextMessage(phone, null, parts, null, null);
                done(id, true, "SMS enviado para " + name + ".", MainActivity.obj("name", name, "phone", phone));
            } catch (Exception e) {
                Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + phone));
                i.putExtra("sms_body", text);
                done(id, start(i), "Não consegui enviar direto; abri o SMS para você enviar.");
            }
        }, () -> {
            Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + phone));
            i.putExtra("sms_body", text);
            done(id, start(i), "Sem permissão de SMS; abri a mensagem para você enviar.");
        });
    }

    void call(String id, String name, String phone) {
        Uri u = Uri.parse("tel:" + phone.replaceAll("[^\\d+]", ""));
        act.withPermissions(new String[]{Manifest.permission.CALL_PHONE},
                () -> done(id, start(new Intent(Intent.ACTION_CALL, u)), "Ligando para " + name + "."),
                () -> done(id, start(new Intent(Intent.ACTION_DIAL, u)), "Abri o discador com o número de " + name + "."));
    }

    // ---------- Relógio ----------
    void alarm(String id, JSONObject a) {
        Intent i = new Intent(AlarmClock.ACTION_SET_ALARM);
        int h = a.optInt("hora", -1), m = a.optInt("minuto", 0);
        if (h < 0 || h > 23) { done(id, false, "Que horas é o alarme?"); return; }
        i.putExtra(AlarmClock.EXTRA_HOUR, h);
        i.putExtra(AlarmClock.EXTRA_MINUTES, m);
        String label = a.optString("rotulo");
        if (!label.isEmpty()) i.putExtra(AlarmClock.EXTRA_MESSAGE, label);
        i.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
        done(id, start(i), String.format("Alarme criado para %02d:%02d.", h, m));
    }

    void timer(String id, JSONObject a) {
        int s = a.optInt("segundos", 0);
        if (s <= 0) { done(id, false, "Quanto tempo de timer?"); return; }
        Intent i = new Intent(AlarmClock.ACTION_SET_TIMER);
        i.putExtra(AlarmClock.EXTRA_LENGTH, s);
        String label = a.optString("rotulo");
        if (!label.isEmpty()) i.putExtra(AlarmClock.EXTRA_MESSAGE, label);
        i.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
        done(id, start(i), "Timer iniciado.");
    }

    // ---------- Aparelho ----------
    void torch(String id, boolean on) {
        try {
            CameraManager cm = (CameraManager) act.getSystemService(Context.CAMERA_SERVICE);
            for (String cid : cm.getCameraIdList()) {
                Boolean flash = cm.getCameraCharacteristics(cid).get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (Boolean.TRUE.equals(flash)) {
                    cm.setTorchMode(cid, on);
                    done(id, true, on ? "Lanterna ligada." : "Lanterna desligada.");
                    return;
                }
            }
            done(id, false, "Este celular não tem lanterna.");
        } catch (Exception e) {
            done(id, false, "Não consegui usar a lanterna.");
        }
    }

    void volume(String id, JSONObject a) {
        AudioManager am = (AudioManager) act.getSystemService(Context.AUDIO_SERVICE);
        int stream = AudioManager.STREAM_MUSIC;
        int max = am.getStreamMaxVolume(stream);
        String acao = norm(a.optString("acao"));
        if (a.has("nivel")) {
            int pct = Math.max(0, Math.min(100, a.optInt("nivel")));
            am.setStreamVolume(stream, Math.round(max * pct / 100f), AudioManager.FLAG_SHOW_UI);
            done(id, true, "Volume em " + pct + "%.");
        } else if (acao.startsWith("aument")) {
            for (int k = 0; k < 2; k++) am.adjustStreamVolume(stream, AudioManager.ADJUST_RAISE, k == 0 ? AudioManager.FLAG_SHOW_UI : 0);
            done(id, true, "Aumentei o volume.");
        } else if (acao.startsWith("diminu") || acao.startsWith("abaix")) {
            for (int k = 0; k < 2; k++) am.adjustStreamVolume(stream, AudioManager.ADJUST_LOWER, k == 0 ? AudioManager.FLAG_SHOW_UI : 0);
            done(id, true, "Diminuí o volume.");
        } else if (acao.startsWith("mud") || acao.startsWith("silen")) {
            am.adjustStreamVolume(stream, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI);
            done(id, true, "Som silenciado.");
        } else {
            am.adjustStreamVolume(stream, AudioManager.ADJUST_SAME, AudioManager.FLAG_SHOW_UI);
            done(id, true, "Controle de volume aberto.");
        }
    }

    void settings(String id, String painel) {
        String p = norm(painel);
        String action;
        if (p.contains("wi")) action = Build.VERSION.SDK_INT >= 29 ? Settings.Panel.ACTION_WIFI : Settings.ACTION_WIFI_SETTINGS;
        else if (p.contains("bluetooth")) action = Settings.ACTION_BLUETOOTH_SETTINGS;
        else if (p.contains("internet") || p.contains("dados")) action = Build.VERSION.SDK_INT >= 29 ? Settings.Panel.ACTION_INTERNET_CONNECTIVITY : Settings.ACTION_WIRELESS_SETTINGS;
        else if (p.contains("volume") || p.contains("som")) action = Build.VERSION.SDK_INT >= 29 ? Settings.Panel.ACTION_VOLUME : Settings.ACTION_SOUND_SETTINGS;
        else if (p.contains("brilho") || p.contains("tela")) action = Settings.ACTION_DISPLAY_SETTINGS;
        else if (p.contains("bateria")) action = Intent.ACTION_POWER_USAGE_SUMMARY;
        else if (p.contains("localiza") || p.contains("gps")) action = Settings.ACTION_LOCATION_SOURCE_SETTINGS;
        else if (p.contains("aviao")) action = Settings.ACTION_AIRPLANE_MODE_SETTINGS;
        else if (p.contains("nfc")) action = Settings.ACTION_NFC_SETTINGS;
        else if (p.contains("notifica")) action = "android.settings.NOTIFICATION_SETTINGS";
        else action = Settings.ACTION_SETTINGS;
        done(id, start(new Intent(action)), "Abri as configurações" + (p.isEmpty() ? "" : " de " + painel) + ".");
    }
}
