package app.kiwy.android;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.util.Base64;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Kiwy para Android: abre o Kiwy (kiwy-ai.vercel.app) e dá a ele acesso ao celular
 * pela ponte "KiwyAndroid" (abrir apps, contatos, WhatsApp, SMS, ligar, alarme, lanterna…).
 */
public class MainActivity extends Activity {
    static final String HOST = "kiwy-ai.vercel.app";
    static final String HOME = "https://" + HOST + "/";
    static final int FILE_REQ = 7, PERM_REQ = 8;

    WebView web;
    ValueCallback<Uri[]> fileCb;
    Actions actions;
    SpeechRecognizer recognizer;
    Runnable permGranted, permDenied;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        if (Build.VERSION.SDK_INT >= 26)
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        actions = new Actions(this);
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(0xfb, 0xfa, 0xf7));
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setSupportZoom(false);
        s.setUserAgentString(s.getUserAgentString() + " KiwyAndroid/1");
        CookieManager.getInstance().setAcceptCookie(true);

        web.addJavascriptInterface(new Bridge(), "KiwyAndroid");
        web.setWebViewClient(new Client());
        web.setWebChromeClient(new Chrome());

        if (state != null) web.restoreState(state);
        else web.loadUrl(startUrl(getIntent()));
    }

    String startUrl(Intent i) {
        String q = "";
        if (i != null) {
            String a = i.getAction();
            Uri d = i.getData();
            if (Intent.ACTION_ASSIST.equals(a) || "android.intent.action.VOICE_COMMAND".equals(a) || (d != null && "live".equals(d.getHost()))) q = "?live=1";
            else if (d != null && "new".equals(d.getHost())) q = "?new=1";
            else if (Intent.ACTION_SEND.equals(a)) {
                String t = i.getStringExtra(Intent.EXTRA_TEXT);
                if (t != null) q = "?text=" + Uri.encode(t);
            }
        }
        return HOME + q;
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        String url = startUrl(i);
        if (!url.equals(HOME)) web.loadUrl(url);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    // O JavaScript continua rodando em segundo plano (não chamamos web.onPause/pauseTimers).
    @Override
    protected void onPause() {
        super.onPause();
        CookieManager.getInstance().flush();
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else moveTaskToBack(true);
    }

    @Override
    protected void onDestroy() {
        if (recognizer != null) recognizer.destroy();
        web.destroy();
        super.onDestroy();
    }

    // ---------- Permissões ----------
    boolean has(String p) {
        return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    void withPermissions(String[] perms, Runnable granted, Runnable denied) {
        List<String> missing = new ArrayList<>();
        for (String p : perms) if (!has(p)) missing.add(p);
        if (missing.isEmpty()) { granted.run(); return; }
        permGranted = granted;
        permDenied = denied;
        requestPermissions(missing.toArray(new String[0]), PERM_REQ);
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        if (req != PERM_REQ) return;
        boolean ok = res.length > 0;
        for (int r : res) if (r != PackageManager.PERMISSION_GRANTED) ok = false;
        Runnable next = ok ? permGranted : permDenied;
        permGranted = null;
        permDenied = null;
        if (next != null) next.run();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == FILE_REQ && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCb = null;
        } else super.onActivityResult(req, res, data);
    }

    // ---------- Comunicação com a página ----------
    void js(String code) {
        runOnUiThread(() -> web.evaluateJavascript(code, null));
    }

    void reply(String id, JSONObject result) {
        js("window.__kiwyNative&&window.__kiwyNative(" + JSONObject.quote(id) + "," + result + ")");
    }

    void speechEvent(JSONObject ev) {
        js("window.__kiwySpeech&&window.__kiwySpeech(" + ev + ")");
    }

    void startListening() {
        runOnUiThread(() -> withPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, () -> {
            if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                speechEvent(obj("type", "error", "message", "Reconhecimento de voz indisponível neste celular."));
                return;
            }
            if (recognizer != null) recognizer.destroy();
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener() {
                public void onReadyForSpeech(Bundle b) { speechEvent(obj("type", "start")); }
                public void onBeginningOfSpeech() {}
                public void onRmsChanged(float v) {}
                public void onBufferReceived(byte[] b) {}
                public void onEndOfSpeech() {}
                public void onError(int code) { speechEvent(obj("type", "error", "message", code == SpeechRecognizer.ERROR_NO_MATCH || code == SpeechRecognizer.ERROR_SPEECH_TIMEOUT ? "Não entendi. Tente de novo." : "Erro no reconhecimento de voz (" + code + ").")); }
                public void onResults(Bundle b) { speechEvent(obj("type", "final", "text", first(b))); }
                public void onPartialResults(Bundle b) { speechEvent(obj("type", "partial", "text", first(b))); }
                public void onEvent(int t, Bundle b) {}
            });
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR");
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
            recognizer.startListening(i);
        }, () -> speechEvent(obj("type", "error", "message", "Permita o microfone para falar com o Kiwy."))));
    }

    static String first(Bundle b) {
        ArrayList<String> r = b == null ? null : b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        return r == null || r.isEmpty() ? "" : r.get(0);
    }

    static JSONObject obj(Object... kv) {
        JSONObject o = new JSONObject();
        try { for (int i = 0; i + 1 < kv.length; i += 2) o.put((String) kv[i], kv[i + 1]); } catch (Exception ignored) {}
        return o;
    }

    // ---------- Navegação ----------
    class Client extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            Uri u = r.getUrl();
            if (HOST.equals(u.getHost())) return false;
            try {
                Intent i = "intent".equals(u.getScheme()) ? Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME) : new Intent(Intent.ACTION_VIEW, u);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "Não foi possível abrir o link.", Toast.LENGTH_SHORT).show();
            }
            return true;
        }
    }

    class Chrome extends WebChromeClient {
        @Override
        public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
            if (fileCb != null) fileCb.onReceiveValue(null);
            fileCb = cb;
            try {
                startActivityForResult(p.createIntent(), FILE_REQ);
            } catch (Exception e) {
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                try { startActivityForResult(i, FILE_REQ); } catch (Exception e2) { fileCb = null; return false; }
            }
            return true;
        }

        // Microfone e câmera para a conversa ao vivo
        @Override
        public void onPermissionRequest(PermissionRequest req) {
            runOnUiThread(() -> {
                List<String> need = new ArrayList<>();
                for (String r : req.getResources()) {
                    if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) need.add(Manifest.permission.RECORD_AUDIO);
                    if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) need.add(Manifest.permission.CAMERA);
                }
                withPermissions(need.toArray(new String[0]), () -> req.grant(req.getResources()), req::deny);
            });
        }
    }

    // ---------- Ponte com o JavaScript ----------
    class Bridge {
        OutputStream out;
        Uri saveUri;
        File saveFile;
        String saveName;

        @JavascriptInterface public boolean isApp() { return true; }

        @JavascriptInterface public int version() { return 1; }

        /** Executa uma ação no celular. O resultado chega em window.__kiwyNative(id, {ok, message}). */
        @JavascriptInterface public void run(String id, String json) {
            runOnUiThread(() -> actions.run(id, json));
        }

        @JavascriptInterface public void listen() { startListening(); }

        @JavascriptInterface public void stopListening() {
            runOnUiThread(() -> { if (recognizer != null) recognizer.stopListening(); });
        }

        @JavascriptInterface public boolean autoSendEnabled() { return AutoSendService.isEnabled(MainActivity.this); }

        @JavascriptInterface public void openAutoSendSettings() {
            runOnUiThread(() -> {
                Toast.makeText(MainActivity.this, "Ative \"Kiwy: enviar no WhatsApp\" na lista de Acessibilidade.", Toast.LENGTH_LONG).show();
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            });
        }

        @JavascriptInterface public void openAppSettings() {
            runOnUiThread(() -> startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))));
        }

        // Salvar arquivos dos Recursos em Downloads/Kiwy (o WebView não baixa blobs sozinho)
        @JavascriptInterface public synchronized boolean saveBegin(String fname, String mime) {
            try {
                saveName = fname.replaceAll("[\\\\/:*?\"<>|]", "_");
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.Downloads.DISPLAY_NAME, saveName);
                    cv.put(MediaStore.Downloads.MIME_TYPE, mime == null || mime.isEmpty() ? "application/octet-stream" : mime);
                    cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Kiwy");
                    cv.put(MediaStore.Downloads.IS_PENDING, 1);
                    saveUri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                    out = getContentResolver().openOutputStream(saveUri);
                } else {
                    File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Kiwy");
                    dir.mkdirs();
                    saveFile = new File(dir, saveName);
                    out = new FileOutputStream(saveFile);
                }
                return true;
            } catch (Exception e) { out = null; return false; }
        }

        @JavascriptInterface public synchronized boolean saveChunk(String b64) {
            try { out.write(Base64.decode(b64, Base64.DEFAULT)); return true; } catch (Exception e) { return false; }
        }

        @JavascriptInterface public synchronized boolean saveEnd() {
            try {
                out.close();
                out = null;
                if (saveUri != null) {
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.Downloads.IS_PENDING, 0);
                    getContentResolver().update(saveUri, cv, null, null);
                }
                final String n = saveName;
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Salvo em Downloads/Kiwy/" + n, Toast.LENGTH_LONG).show());
                saveUri = null;
                saveFile = null;
                return true;
            } catch (Exception e) { return false; }
        }

        @JavascriptInterface public synchronized void saveAbort() {
            try { if (out != null) out.close(); } catch (Exception ignored) {}
            try {
                if (saveUri != null) getContentResolver().delete(saveUri, null, null);
                if (saveFile != null) saveFile.delete();
            } catch (Exception ignored) {}
            out = null; saveUri = null; saveFile = null;
        }
    }
}
